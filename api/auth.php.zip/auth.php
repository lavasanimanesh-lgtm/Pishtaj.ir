<?php
// PTF Auth - JWT-like HMAC token v29.6
// v31.7.4 BUG-AUDIT-005: Use centralized secret management
require_once __DIR__ . '/secrets.php';

function auth_secret(){
  $paths = [dirname(__DIR__,2).'/codegen-secret.php', dirname(__DIR__).'/auth-secret.php', __DIR__.'/auth-secret.php'];
  foreach($paths as $p){ if(file_exists($p)){ $s=@include $p; if(is_string($s)&&strlen($s)>10) return $s; if(is_array($s)&&isset($s['secret'])) return $s['secret']; } }
  // v31.7.4: Use centralized secret loading instead of hardcoded fallback
  return load_ptf_secret('auth_key', 'ptf-crm-secret-key-2026-v29.6');
}
function auth_tokens_file(){
  $dir = __DIR__ . '/../crm/data';
  if(!is_dir($dir)){ @mkdir($dir,0755,true); }
  return $dir.'/tokens.json';
}
function auth_load_tokens(){
  $f=auth_tokens_file();
  if(!file_exists($f)) return [];
  $raw=@file_get_contents($f); $j=json_decode($raw,true); return is_array($j)?$j:[];
}
function auth_save_tokens($tokens){
  $f=auth_tokens_file();
  // cleanup expired
  $now=time();
  foreach($tokens as $tok=>$info){ if(isset($info['exp']) && $info['exp']<$now) unset($tokens[$tok]); }
  @file_put_contents($f, json_encode($tokens, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), LOCK_EX);
}
function auth_generate_token($username,$role){
  $secret=auth_secret();
  $now=time(); $exp=$now+86400*7; // 7 days
  $payload = $username.'|'.$role.'|'.$now.'|'.bin2hex(random_bytes(8));
  $sig = hash_hmac('sha256', $payload, $secret);
  $token = base64_encode($payload.'|'.$sig);
  $tokens=auth_load_tokens();
  $tokens[$token]=['user'=>$username,'role'=>$role,'iat'=>$now,'exp'=>$exp,'ip'=>$_SERVER['REMOTE_ADDR']??''];
  auth_save_tokens($tokens);
  return $token;
}
function auth_verify_token($token){
  if(empty($token)) return false;
  $tokens=auth_load_tokens();
  if(!isset($tokens[$token])) return false;
  $info=$tokens[$token];
  if(!isset($info['exp']) || $info['exp']<time()) return false;
  // optionally check IP loosely
  return $info;
}
function auth_get_header_token(){
  $headers = function_exists('getallheaders') ? getallheaders() : [];
  $tok = $headers['X-CRM-Token'] ?? $headers['x-crm-token'] ?? $_SERVER['HTTP_X_CRM_TOKEN'] ?? $_POST['token'] ?? $_GET['token'] ?? '';
  if(is_array($tok)) $tok=$tok[0]??'';
  return trim($tok);
}
